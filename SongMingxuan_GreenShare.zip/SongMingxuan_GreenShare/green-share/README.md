# Green Share

How much can the distribution of neighborhood park space change when the citywide total stays the same? Green Share explores this question across Chicago's 77 community areas. It combines public park boundaries and population estimates, maps differences in park area per resident, and compares three simple ways to allocate a shared pool of park area.


## Data 
This project uses three public Chicago datasets: ACS 2023 population estimates for 77 communities, 77 community-area boundaries, and 617 park property polygons dated 4 November 2016. All datasets were downloaded without registration or an API key and require no additional manual annotation. The analysis combines population estimates with park footprints to calculate park property area per resident. These footprints can include paved and built surfaces, so the measure does not represent vegetation cover, walking access, or individual exposure.
